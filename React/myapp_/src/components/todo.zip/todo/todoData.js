export const dummyData = [
    {
        id: 1,
        isDone: true,
        content: 'React Study',
        wdate: new Date().getTime(),
    },
    {
        id: 2,
        isDone: false,
        content: '방 청소 하기',
        wdate: new Date().getTime(),
    },
    {
        id: 3,
        isDone: false,
        content: '운동 하기',
        wdate: new Date().getTime(),
    },
];
