// JsxEx4.jsx
export function GetLang() {
    return <h2>내가 사용하는 언어는 React입니다</h2>;
}
export function GetJob() {
    return <h2>나의 직업은 프런트엔드 개발자입니다</h2>;
}
export default function GetPet() {
    return <h2>나의 반려견은 토미입니다</h2>;
}
