// JsxEx7.jsx
export default function JsxEx7() {
    return (
        <div>
            <header>
                <h1>Welcome to MyApp</h1>
            </header>
            <section>
                React CSS - Inline Style 적용하는 방법
                <br />
                리액트에서는 style속성값으로 문자열이 아닌 
                자바스크립트 객체를 할당해야 해요
                <br />
                CSS속성명은 카멜 표기법(Camel Case)으로 작성해야 해요
            </section>
        </div>
    );
}
