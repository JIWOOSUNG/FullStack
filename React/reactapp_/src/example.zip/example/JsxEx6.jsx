// JsxEx6.jsx
const GetName = () => {
    return (
        <div className="alert alert-danger">
            <h2>내 이름은 백성애입니다</h2>
        </div>
    );
};
export default GetName;
