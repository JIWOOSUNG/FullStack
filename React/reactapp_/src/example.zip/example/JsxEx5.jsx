// JsxEx5.jsx
//import React from 'react'
export default function () {
    return (
        <div className="alert alert-warning my-3">
            <h2>익명함수로 만든 컴포넌트에요</h2>
        </div>
    );
}
