// JsxEx3.jsx
function GetBrand() {
    //pascal표기법 대문자로 시작
    return <h2>내 노트북은 LG gram 노트북입니다</h2>;
}
function GetOS() {
    return <h2>내가 사용하는 운영체제(OS)는 Windows입니다</h2>;
}

export { GetBrand, GetOS };
